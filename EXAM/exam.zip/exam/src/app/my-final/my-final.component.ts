import { Component, OnInit } from '@angular/core';
import { Valute , Actions } from './classes';
import { from } from 'rxjs';

@Component({
  selector: 'app-my-final',
  templateUrl: './my-final.component.html',
  styleUrls: ['./my-final.component.css']
})
export class MyFinalComponent implements OnInit {

public coinNameInput:string;
public coinVlueInput:number;
public exchangeFromNameInput:string;
public exchangeToNameInput:number;
public exchangeNumber:number;
public arrOfAllCoins: Valute[] = new Array();
public arrOfAllMyActions: Actions[] = new Array();

public convertFromRate:number;
public convertToRate:number; 
public result:number;

public i:number;
public j:number;
public listIndex:number;
public chackName:string;
public x:string;
public flag:boolean;

public Name:string;
public Value:number;

public page1:boolean;
public page2:boolean;
public logDiv:boolean;




  constructor() { }

 public turnToPage1():void{
   this.page2 = false;
   this.page1 = true;
 }

 public turnToPage2():void{
  this.page1 = false;
  this.page2 = true;
}

public showLogDiv():void{
  this.logDiv = true;
}

public goToFacebook():void{
  herf = src: "http://www.facebook.com"
}


convert():void{
  for (this.i = 0; this.i<this.arrOfAllCoins.length;this.i++){
    if (this.exchangeFromNameInput == this.arrOfAllCoins[this.i].getCoinName()){
      this.convertFromRate = this.arrOfAllCoins[this.i].getCoinValue();

    }
    if (this.exchangeToNameInput == this.arrOfAllCoins[this.i].getCoinName()){
      this.convertToRate = this.arrOfAllCoins[this.i].getCoinValue();
  }

  this.result = this.convertFromRate * this.exchangeNumber * this.convertToRate;

  this.arrOfAllMyActions.push(new Action(this.exchangeFromNameInput, this.this.convertFromRate , this.exchangeToNameInput , this.convertToRate , this.exchangeNumber));

}



  public updateLogOfCoins():void{
    debugger;
    this.chackName = this.coinNameInput;
    this.chackName = this.chackName.toUpperCase();
        for(this.i=0;this.i<this.arrOfAllCoins.length;i++){
      this.x = this.arrOfAllCoins[this.i].getCoinName();
      if (this.chackName == this.x   ){
        this.arrOfAllCoins[this.i].setCoinValue(this.coinVlueInput);
        this.flag = true;
        break;
          }
        }  
        if (this.flag == false){
          this.arrOfAllCoins.push(new Valute(this.chackName,this.coinVlueInput));
        }
        this.flag = false;
    }


  ngOnInit() {
this.page1 = true;
this.page2 = false;

this.i = 0;
this.j = 0;
this.flag = false;
this.logDiv = false;

this.arrOfAllCoins.push(new Valute("DOLLAR",4));
this.arrOfAllCoins.push(new Valute("EURO",5));
this.arrOfAllCoins.push(new Valute("SHEKEL",1));
  }

}
