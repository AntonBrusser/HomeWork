showTheBigest(mat){
    var row;
    var col;
    var resArr = [];
    var tempSum = 0;
    var bigestSum = 0;
    var counter = 0;
    for(row = 0; row<mat.length; row ++){
        for(col = 0 ; col<mat.length; col++){
            tempSum += mat[row][col];
            if (tempSum > bigestSum){
                tempSum = bigestSum;
            }
            resArr[row] = bigestSum;
        }
    }
    for (col = 0; row<mat.length; row ++){
        for(row = 0 ; col<mat.length; col++){
            if (col > row){
                counter += mat[col][row];
            }
        } 
    }

return resArr = [];
console.log = counter;
}